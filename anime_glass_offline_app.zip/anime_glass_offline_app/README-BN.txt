Anime Glass Offline App

ফাইলগুলো HTTPS hosting (যেমন GitHub Pages) এ আপলোড করতে হবে। index.html, manifest.webmanifest, sw.js এবং icon.svg একই ফোল্ডারে রাখবে।

Chrome-এ HTTPS URL খুলে ⋮ > Install app / Add to Home screen চাপবে। প্রথমবার অনলাইনে খুলে install করার পর App shell offline-এ খুলবে।

ভিডিও যোগ করলে তা IndexedDB-তে কপি হয়; Gallery-এর মূল ফাইল মুছলেও কপি থাকবে। তবে Chrome-এর Site data/Storage clear করলে বা Browser app data মুছলে ভিডিও হারাতে পারে। বড় ভিডিওর জন্য ফোনে পর্যাপ্ত খালি জায়গা দরকার।

এই Web Player HTML5 browser playback ব্যবহার করে। MP4 (H.264/AAC) সাধারণত সবচেয়ে compatible। MKV/AC3 বা অন্য codec, embedded subtitle, audio track selection সব Android browser-এ guaranteed নয়। VTT subtitle file আলাদা করে load করা যায়।
